-----------------------------------
-- Area: Abyssea - La Theine
--  Mob: Luison
-----------------------------------
mixins = { require("scripts/mixins/families/gnole") }
-----------------------------------
local entity = {}

entity.onMobDeath = function(mob, player, optParams)
end

return entity
